'use strict';
/*
 * Store server: Node.js (22+) + built-in SQLite (node:sqlite). No npm packages needed.
 *   node server.js                          -> start (PORT=3000 by default)
 *   node server.js --reset-password EMAIL NEWPASS   -> reset / create a user's password (owner if none exists)
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
process.removeAllListeners('warning');
const { DatabaseSync } = require('node:sqlite');

const PORT = +process.env.PORT || 3000;
const DB_FILE = process.env.DB_FILE || path.join(__dirname, 'data', 'shop.db');
const PUB = path.join(__dirname, 'public');
const DEFAULT_OWNER = (process.env.OWNER_EMAIL || 'gobaraahmed822@gmail.com').toLowerCase();
fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });

const db = new DatabaseSync(DB_FILE);
db.exec(`
PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY, v TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS users(
  email TEXT PRIMARY KEY, salt TEXT NOT NULL, hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user', perm TEXT NOT NULL DEFAULT '[]', act TEXT);
CREATE TABLE IF NOT EXISTS sessions(tok TEXT PRIMARY KEY, email TEXT NOT NULL, exp INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY, j TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS reviews(id INTEGER PRIMARY KEY, j TEXT NOT NULL);
`);

/* ---------- helpers ---------- */
const sha256 = s => crypto.createHash('sha256').update(s).digest('hex');
const HEX64 = /^[0-9a-f]{64}$/;
function hashPw(h, salt = crypto.randomBytes(16).toString('hex')) {
  return { salt, hash: crypto.scryptSync(h, salt, 64).toString('hex') };
}
function checkPw(h, salt, hash) {
  const a = Buffer.from(crypto.scryptSync(h, salt, 64).toString('hex'));
  const b = Buffer.from(hash);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
function setUser(email, clientHash, role, perm, act) {
  const { salt, hash } = hashPw(clientHash);
  db.prepare(`INSERT INTO users(email,salt,hash,role,perm,act) VALUES(?,?,?,?,?,?)
    ON CONFLICT(email) DO UPDATE SET salt=excluded.salt,hash=excluded.hash`)
    .run(email, salt, hash, role, JSON.stringify(perm || []), act ? JSON.stringify(act) : null);
}
const getKV = k => { const r = db.prepare('SELECT v FROM kv WHERE k=?').get(k); return r ? JSON.parse(r.v) : null; };
const putKV = (k, v) => db.prepare('INSERT INTO kv(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v').run(k, JSON.stringify(v));
const tx = fn => { db.exec('BEGIN IMMEDIATE'); try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { db.exec('ROLLBACK'); throw e; } };

/* ---------- CLI: password reset ---------- */
const argv = process.argv.slice(2);
if (argv[0] === '--reset-password') {
  const email = (argv[1] || '').trim().toLowerCase(), pw = argv[2] || '';
  if (!email || pw.length < 8) { console.error('Usage: node server.js --reset-password EMAIL NEWPASSWORD (8+ chars)'); process.exit(1); }
  const ex = db.prepare('SELECT role FROM users WHERE email=?').get(email);
  const hasOwner = db.prepare("SELECT 1 FROM users WHERE role='owner'").get();
  setUser(email, sha256(pw), ex ? ex.role : (hasOwner ? 'user' : 'owner'), [], null);
  db.prepare('DELETE FROM sessions WHERE email=?').run(email);
  console.log(`Password set for ${email} (${ex ? ex.role : (hasOwner ? 'user' : 'owner')}). Existing sessions were signed out.`);
  process.exit(0);
}

/* first run: create the owner with a random password (printed once) */
if (!db.prepare("SELECT 1 FROM users WHERE role='owner'").get()) {
  const pw = process.env.OWNER_PASSWORD || crypto.randomBytes(9).toString('base64url');
  setUser(DEFAULT_OWNER, sha256(pw), 'owner', [], null);
  console.log('\n=== Owner account created ===\n  email   : ' + DEFAULT_OWNER + '\n  password: ' + pw + '\n  (change it from the admin panel; reset anytime with: node server.js --reset-password EMAIL NEWPASS)\n');
}

/* ---------- sessions & rate limiting ---------- */
const SESSION_REMEMBER = 30 * 864e5, SESSION_SHORT = 12 * 36e5;
function newSession(email, remember) {
  const tok = crypto.randomBytes(32).toString('base64url');
  const ttl = remember ? SESSION_REMEMBER : SESSION_SHORT;
  db.prepare('INSERT INTO sessions(tok,email,exp) VALUES(?,?,?)').run(sha256(tok), email, Date.now() + ttl);
  return { tok, ttl };
}
function cookieOf(req, n) {
  const m = (req.headers.cookie || '').split(/;\s*/).find(c => c.startsWith(n + '='));
  return m ? decodeURIComponent(m.slice(n.length + 1)) : '';
}
function sessionUser(req) {
  const tok = cookieOf(req, 'sid');
  if (!tok) return null;
  const s = db.prepare('SELECT email,exp FROM sessions WHERE tok=?').get(sha256(tok));
  if (!s) return null;
  if (s.exp < Date.now()) { db.prepare('DELETE FROM sessions WHERE tok=?').run(sha256(tok)); return null; }
  const u = db.prepare('SELECT email,role,perm,act FROM users WHERE email=?').get(s.email);
  return u || null;
}
const hits = new Map();
function limited(key, max, windowMs) {
  const now = Date.now(), a = (hits.get(key) || []).filter(t => now - t < windowMs);
  if (a.length >= max) { hits.set(key, a); return true; }
  a.push(now); hits.set(key, a); return false;
}
setInterval(() => { const now = Date.now(); for (const [k, a] of hits) if (!a.some(t => now - t < 36e5)) hits.delete(k); db.prepare('DELETE FROM sessions WHERE exp<?').run(now); }, 600000).unref();

/* ---------- state assembly ---------- */
const PRIVATE_KEYS = ['fin', 'invl', 'banks', 'carts'];
function publicUser(u) { return { e: u.email, role: u.role, perm: JSON.parse(u.perm || '[]'), ...(u.act ? { act: JSON.parse(u.act) } : {}) }; }
function allOrders() { return db.prepare('SELECT j FROM orders ORDER BY id').all().map(r => JSON.parse(r.j)); }
function allReviews() { return db.prepare('SELECT j FROM reviews ORDER BY id').all().map(r => JSON.parse(r.j)); }
function publicState() {
  const st = getKV('state');
  if (!st) return { empty: true, reviews: allReviews() };
  const o = { ...st };
  PRIVATE_KEYS.forEach(k => delete o[k]);
  o.users = []; o.orders = []; o.reviews = allReviews();
  return o;
}
function adminState() {
  const st = getKV('state');
  if (!st) return { empty: true, users: db.prepare('SELECT email,role,perm,act FROM users').all().map(publicUser), _asof: Date.now() };
  return { ...st, users: db.prepare('SELECT email,role,perm,act FROM users ORDER BY rowid').all().map(publicUser), orders: allOrders(), reviews: allReviews(), _asof: Date.now() };
}

function saveAdminState(me, body) {
  const asof = +body._asof || 0;
  const isOwner = me.role === 'owner';
  tx(() => {
    const prev = getKV('state') || {};
    const st = {};
    for (const k of Object.keys(body)) if (!['users', 'orders', 'reviews', '_asof', 'empty'].includes(k)) st[k] = body[k];
    if (!isOwner && prev.set) st.set = prev.set;                // only the owner may change settings
    putKV('state', st);

    // orders: upsert, delete only ones the admin has actually seen (created before _asof)
    const ids = new Set();
    for (const o of Array.isArray(body.orders) ? body.orders : []) {
      if (!o || !Number.isFinite(+o.id)) continue;
      ids.add(+o.id);
      db.prepare('INSERT INTO orders(id,j) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET j=excluded.j').run(+o.id, JSON.stringify(o));
    }
    for (const r of db.prepare('SELECT id FROM orders').all()) if (!ids.has(r.id) && r.id <= asof) db.prepare('DELETE FROM orders WHERE id=?').run(r.id);

    const rids = new Set();
    for (const r of Array.isArray(body.reviews) ? body.reviews : []) {
      if (!r || !Number.isFinite(+r.d)) continue;
      rids.add(+r.d);
      db.prepare('INSERT INTO reviews(id,j) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET j=excluded.j').run(+r.d, JSON.stringify(r));
    }
    for (const r of db.prepare('SELECT id FROM reviews').all()) if (!rids.has(r.id) && r.id <= asof) db.prepare('DELETE FROM reviews WHERE id=?').run(r.id);

    // users: owner only
    if (isOwner && Array.isArray(body.users)) {
      const keep = new Set();
      for (const u of body.users) {
        if (!u || typeof u.e !== 'string') continue;
        const email = u.e.trim().toLowerCase();
        if (!email || email.length > 200) continue;
        const ex = db.prepare('SELECT role FROM users WHERE email=?').get(email);
        keep.add(email);
        const perm = Array.isArray(u.perm) ? u.perm.filter(x => typeof x === 'string') : [];
        const act = Array.isArray(u.act) ? u.act.filter(x => typeof x === 'string') : null;
        if (ex) {
          db.prepare('UPDATE users SET perm=?,act=? WHERE email=?').run(JSON.stringify(ex.role === 'owner' ? [] : perm), ex.role === 'owner' ? null : (act ? JSON.stringify(act) : null), email);
          if (typeof u.h === 'string' && HEX64.test(u.h)) { const { salt, hash } = hashPw(u.h); db.prepare('UPDATE users SET salt=?,hash=? WHERE email=?').run(salt, hash, email); db.prepare('DELETE FROM sessions WHERE email=?').run(email); }
        } else if (typeof u.h === 'string' && HEX64.test(u.h)) {
          setUser(email, u.h, 'user', perm, act);            // new users are never owners
        }
      }
      for (const r of db.prepare("SELECT email FROM users WHERE role!='owner'").all()) if (!keep.has(r.email)) { db.prepare('DELETE FROM users WHERE email=?').run(r.email); db.prepare('DELETE FROM sessions WHERE email=?').run(r.email); }
    }
  });
}

/* ---------- public actions ---------- */
const str = (v, n) => String(v == null ? '' : v).slice(0, n);
function placeOrder(b) {
  const n = str(b.n, 100).trim(), ph = str(b.ph, 20).trim(), addr = str(b.addr, 300).trim(), note = str(b.note, 500).trim(), pay = str(b.pay, 60).trim();
  if (!n || !/^01[0125]\d{8}$/.test(ph) || !addr || !pay) throw new Error('بيانات الطلب غير صحيحة');
  if (!Array.isArray(b.items) || !b.items.length || b.items.length > 100) throw new Error('السلة فارغة');
  return tx(() => {
    const st = getKV('state');
    if (!st || !Array.isArray(st.prods)) throw new Error('المتجر غير جاهز');
    const items = []; let total = 0;
    for (const c of b.items) {
      const p = st.prods.find(x => x.id == c.id), q = Math.floor(+c.q);
      if (!p || !(q > 0)) throw new Error('منتج غير موجود');
      if (p.q < q) throw new Error('الكمية غير متاحة: ' + p.n);
    }
    for (const c of b.items) {
      const p = st.prods.find(x => x.id == c.id), q = Math.floor(+c.q);
      p.q -= q;
      const price = Math.round(p.p * (100 - (p.d || 0)) / 100);
      items.push({ id: p.id, n: p.n, q, p: price }); total += price * q;
    }
    putKV('state', st);
    let id = Date.now();
    while (db.prepare('SELECT 1 FROM orders WHERE id=?').get(id)) id++;
    const o = { id, n, ph, addr, note, items, total, pay, st: 'new', d: id };
    db.prepare('INSERT INTO orders(id,j) VALUES(?,?)').run(id, JSON.stringify(o));
    return o;
  });
}
function addReview(b) {
  const t = str(b.t, 1000).trim(); if (!t) throw new Error('اكتب التقييم');
  let id = Date.now(); while (db.prepare('SELECT 1 FROM reviews WHERE id=?').get(id)) id++;
  const r = { n: str(b.n, 80).trim() || '-', pid: +b.pid || 0, s: Math.min(5, Math.max(1, +b.s || 5)), t, d: id };
  db.prepare('INSERT INTO reviews(id,j) VALUES(?,?)').run(id, JSON.stringify(r));
  return r;
}
function addCart(b) {
  tx(() => {
    const st = getKV('state'); if (!st) return;
    (st.carts = st.carts || []).push({ d: Date.now(), e: str(b.e, 200), items: (Array.isArray(b.items) ? b.items : []).slice(0, 50).map(x => str(x, 200)), total: +b.total || 0 });
    st.carts = st.carts.slice(-500); putKV('state', st);
  });
}

/* ---------- HTTP ---------- */
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.json': 'application/json', '.webp': 'image/webp' };
function send(res, code, obj, headers = {}) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(body);
}
function readBody(req, max = 60e6) {
  return new Promise((ok, no) => {
    let n = 0; const ch = [];
    req.on('data', c => { n += c.length; if (n > max) { no(new Error('too large')); req.destroy(); } else ch.push(c); });
    req.on('end', () => { try { ok(JSON.parse(Buffer.concat(ch).toString() || '{}')); } catch (e) { no(new Error('bad json')); } });
    req.on('error', no);
  });
}

async function api(req, res, url) {
  const ip = req.socket.remoteAddress || '?';
  const secure = req.headers['x-forwarded-proto'] === 'https';
  const m = req.method, p = url.pathname;
  if (m !== 'GET') {
    if (!/application\/json/.test(req.headers['content-type'] || '')) return send(res, 415, { error: 'json only' });
    const o = req.headers.origin; if (o && new URL(o).host !== req.headers.host) return send(res, 403, { error: 'bad origin' });
  }
  const me = sessionUser(req);
  const needAdmin = () => { if (!me) { send(res, 401, { error: 'unauthorized' }); return false; } return true; };

  if (m === 'GET' && p === '/api/state') return send(res, 200, publicState());
  if (m === 'GET' && p === '/api/me') return send(res, 200, me ? { ok: true, e: me.email, role: me.role } : { ok: false });

  if (m === 'POST' && p === '/api/login') {
    const b = await readBody(req, 1e4);
    const email = str(b.email, 200).trim().toLowerCase(), h = str(b.h, 64);
    if (limited('login:' + ip, 10, 600000) || limited('loginu:' + email, 10, 600000)) return send(res, 429, { error: 'محاولات كثيرة، حاول بعد قليل' });
    const u = db.prepare('SELECT * FROM users WHERE email=?').get(email);
    // always do the scrypt work so timing doesn't reveal whether the email exists
    const ok = HEX64.test(h) && (u ? checkPw(h, u.salt, u.hash) : (checkPw(h, '00', '00'.repeat(64)), false));
    if (!ok) return send(res, 401, { error: 'bad credentials' });
    const { tok, ttl } = newSession(u.email, !!b.remember);
    return send(res, 200, { ok: true, e: u.email, role: u.role }, { 'Set-Cookie': `sid=${tok}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${Math.floor(ttl / 1000)}${secure ? '; Secure' : ''}` });
  }
  if (m === 'POST' && p === '/api/logout') {
    const tok = cookieOf(req, 'sid'); if (tok) db.prepare('DELETE FROM sessions WHERE tok=?').run(sha256(tok));
    return send(res, 200, { ok: true }, { 'Set-Cookie': 'sid=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0' });
  }
  if (m === 'POST' && p === '/api/order') {
    if (limited('order:' + ip, 20, 36e5)) return send(res, 429, { error: 'too many' });
    try { return send(res, 200, { ok: true, order: placeOrder(await readBody(req, 2e5)) }); } catch (e) { return send(res, 400, { error: e.message }); }
  }
  if (m === 'POST' && p === '/api/review') {
    if (limited('rev:' + ip, 10, 36e5)) return send(res, 429, { error: 'too many' });
    try { return send(res, 200, { ok: true, review: addReview(await readBody(req, 2e4)) }); } catch (e) { return send(res, 400, { error: e.message }); }
  }
  if (m === 'POST' && p === '/api/cart') {
    if (limited('cart:' + ip, 10, 36e5)) return send(res, 429, { error: 'too many' });
    addCart(await readBody(req, 2e4)); return send(res, 200, { ok: true });
  }

  if (p === '/api/admin/state') {
    if (!needAdmin()) return;
    if (m === 'GET') return send(res, 200, adminState());
    if (m === 'PUT') { try { saveAdminState(me, await readBody(req)); return send(res, 200, { ok: true, asof: Date.now() }); } catch (e) { return send(res, 400, { error: e.message }); } }
  }
  if (m === 'GET' && p === '/api/admin/poll') {
    if (!needAdmin()) return;
    const st = getKV('state') || {};
    return send(res, 200, { orders: allOrders(), reviews: allReviews(), q: Object.fromEntries((st.prods || []).map(x => [x.id, x.q])), carts: st.carts || [], asof: Date.now() });
  }
  send(res, 404, { error: 'not found' });
}

function serveStatic(req, res, url) {
  let f = decodeURIComponent(url.pathname); if (f === '/') f = '/index.html';
  const full = path.join(PUB, path.normalize(f));
  if (!full.startsWith(PUB + path.sep) || path.basename(full).startsWith('.')) { res.writeHead(404); return res.end('Not found'); }
  fs.readFile(full, (err, buf) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(full)] || 'application/octet-stream', 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'SAMEORIGIN', 'Cache-Control': 'no-cache' });
    res.end(buf);
  });
}

http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
    serveStatic(req, res, url);
  } catch (e) {
    console.error(e);
    if (!res.headersSent) send(res, 500, { error: 'server error' });
  }
}).listen(PORT, () => console.log(`Store running on http://localhost:${PORT}  (database: ${DB_FILE})`));
